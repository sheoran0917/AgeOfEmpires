﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AgeOfEmpires
{
    class AoE
    {
        public IAttacking attackingNumber;
        
        public AoE(int unit1, int unit2)
        {
          attackingNumber = new WinnerCalculator(unit1, unit2);
        }
        public void CalculateWinner()
        {
            try
            {
                attackingNumber.CalculateWinner();
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    }
}
