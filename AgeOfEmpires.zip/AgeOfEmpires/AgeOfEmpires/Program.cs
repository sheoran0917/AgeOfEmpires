﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AgeOfEmpires
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // Calculate two random integer between 1 and 100
                Random random = new Random();
                int randomNumber1 = random.Next(1, 100);

                // Get second random number that is different from randomNumber1
                int randomNumber2 = random.Next(1, 100);
                randomNumber2 = randomNumber2 == randomNumber1 ? random.Next(1, 100) : randomNumber2;

                AoE aoEUnits = new AoE(randomNumber1, randomNumber2);
                aoEUnits.CalculateWinner();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
            }
            Console.ReadLine();
        }
    }
}
