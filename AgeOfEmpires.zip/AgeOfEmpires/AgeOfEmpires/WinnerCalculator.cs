﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Net;
using System.Runtime.Serialization.Json;

namespace AgeOfEmpires
{
    class WinnerCalculator : IAttacking
    {
        int U1, U2;
        public WinnerCalculator(int unit1, int unit2)
        {
            U1 = unit1;
            U2 = unit2;
        }
        public void CalculateWinner()
        {
            try
            {
                //Get URL from App Config
                string URL = ConfigurationManager.AppSettings["AOEURL"];

                //Update the url with unit number 1
                string unit1RequestUrl = URL.Replace("{ID}", Convert.ToString(U1));

                APIResultData unit1Response = new APIResultData();
                unit1Response = GetResponse(unit1RequestUrl);

                //Update the url with unit number 2
                string unit2RequestUrl = URL.Replace("{ID}", Convert.ToString(U2));
                APIResultData unit2Response = new APIResultData();
                unit2Response = GetResponse(unit2RequestUrl);

                APIResultData Winner = GetWinner(unit1Response, unit2Response);

                if (Winner != null)
                {
                    Console.WriteLine(String.Format("Name of the units are : {0}{1}{2}{3}", Environment.NewLine, unit1Response.name, Environment.NewLine, unit2Response.name));
                    Console.WriteLine(String.Format("Winner is : {0}", Winner.name));
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public APIResultData GetResponse(string url)
        {
            try
            {
                System.Net.HttpWebRequest request = WebRequest.Create(url) as HttpWebRequest;
                using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
                {
                    if (response.StatusCode != HttpStatusCode.OK)
                        throw new Exception(String.Format(
                        "Server error (HTTP {0}: {1}).",
                        response.StatusCode,
                        response.StatusDescription));

                    DataContractJsonSerializer jsonSerializer = new DataContractJsonSerializer(typeof(APIResultData));
                    object objResponse = jsonSerializer.ReadObject(response.GetResponseStream());
                    APIResultData jsonResponse = objResponse as APIResultData;

                    return jsonResponse;
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }

                
        }
        public APIResultData GetWinner(APIResultData unit1Response, APIResultData unit2Response)
        {
            APIResultData winner = null;
            try
            {
                
                if (unit1Response != null && unit2Response != null)
                {
                    if(unit1Response.attack > 0 && unit2Response.attack > 0)
                    {
                        int unit1Hits, unit2Hits = 0;
                        unit1Hits = unit2Response.hit_points / unit1Response.attack;
                        unit2Hits = unit1Response.hit_points / unit2Response.attack;

                        if (unit1Hits < unit2Hits)
                            winner = unit1Response;
                        else if (unit1Hits > unit2Hits)
                            winner = unit2Response;
                        else if(unit2Hits == unit1Hits)
                            Console.WriteLine(String.Format("Winner cannot be determined between Units {0} and {1}.{2}Because both have same hits.", unit1Response.name, unit2Response.name, Environment.NewLine));
                    }
                    else
                    {
                        Console.WriteLine(String.Format("Winner cannot be determined between Units {0} and {1}.{2}Because attack of any one of the unit is null or zero in response.", unit1Response.name,unit2Response.name,Environment.NewLine));
                        throw new DivideByZeroException();
                    }
                }

                return winner;
            }
            catch(Exception ex)
            {
                throw ex;
            }

            
        }
    }
}
