﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace AgeOfEmpires
{
    
    public class APIResultData
    {
        public int id { get; set; }
        
        public string name { get; set; }
        
        public string description { get; set; }
       
        public string expansion { get; set; }
       
        public string age { get; set; }
      
        public string created_in { get; set; }
        
        public costs cost { get; set; }

       
        public float reload_time { get; set; }

        public float movement_rate { get; set; }

        
        public int line_of_sight { get; set; }

        
        public int hit_points { get; set; }
       
        public string range { get; set; }
        public int attack { get; set; }
       
        public string armor { get; set; }
        
        public List<string> attack_bonus { get; set; }
    }
    public class costs
    {
        public int Food { get; set; }
        public int Gold { get; set; }
    }
}
